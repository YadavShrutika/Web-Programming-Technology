const express = require("express");
const EventBooking = require("../models/event");
const router = express.Router();

router.post("/book-event", async (req, res) => {
  const {
    title: eventTitle,
    date: eventDate,
    time: eventTime,
    venue: eventVenue,
    tickets: numberOfTickets,
  } = req.body;

  try {
    if (
      !eventTitle ||
      !eventDate ||
      !eventTime ||
      !eventVenue ||
      !numberOfTickets
    ) {
      return res.status(400).json({
        success: false,
        message:
          "Please provide all required fields: eventTitle, eventDate, eventTime, eventVenue, numberOfTickets",
      });
    }

    // Insert data into the EventBooking table
    const newBooking = await EventBooking.create({
      eventTitle,
      eventDate,
      eventTime,
      eventVenue,
      numberOfTickets,
    });

    res.status(201).json({
      success: true,
      message: "Booking created successfully!",
      booking: newBooking,
    });
  } catch (error) {
    console.error("Error creating booking:", error);
    res.status(500).json({
      success: false,
      message: "Error creating booking",
      error: error.message,
    });
  }
});

router.get("/bookings", async (req, res) => {
  try {
    const bookings = await EventBooking.findAll();
    res.json(bookings);
  } catch (error) {
    console.error("Error fetching bookings:", error);
    res.status(500).json({
      success: false,
      message: "Error fetching bookings",
      error: error.message,
    });
  }
});

router.delete("/bookings/:id", async (req, res) => {
  const bookingId = req.params.id;
  try {
    const deletedBooking = await EventBooking.destroy({
      where: { id: bookingId },
    });

    if (deletedBooking) {
      res.json({
        success: true,
        message: "Booking deleted successfully!",
      });
    } else {
      res.status(404).json({
        success: false,
        message: "Booking not found",
      });
    }
  } catch (error) {
    console.error("Error deleting booking:", error);
    res.status(500).json({
      success: false,
      message: "Error deleting booking",
      error: error.message,
    });
  }
});

router.put("/bookings/:id", async (req, res) => {
  const bookingId = req.params.id;
  const { numberOfTickets } = req.body; // The new ticket count from the request body

  try {
    const booking = await EventBooking.findByPk(bookingId);

    if (booking) {
      booking.numberOfTickets = numberOfTickets; // Update the ticket count
      await booking.save();

      res.json({
        success: true,
        message: "Ticket count updated successfully!",
      });
    } else {
      res.status(404).json({
        success: false,
        message: "Booking not found!",
      });
    }
  } catch (error) {
    console.error("Error updating ticket count:", error);
    res.status(500).json({
      success: false,
      message: "Error updating ticket count!",
      error: error.message,
    });
  }
});

module.exports = router;
