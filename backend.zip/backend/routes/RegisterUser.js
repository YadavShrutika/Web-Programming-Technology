const express = require("express");
const User = require("../models/user");
const router = express.Router();

// Example route to create a user
router.post("/register", async (req, res) => {
  const { name, email, password } = req.body;
 
  try {
      
    const user = await User.create({ name, email, password });
  
    // Send a response without sensitive user data
    res.status(201).send({
      message: "User created successfully!",
      user: { id: user.id, name: user.name, email: user.email },
    });
  } catch (error) {
    if (error.name === "SequelizeUniqueConstraintError") {
      return res.status(400).send({
        message: "Email already exists. Please use a different email.",
      });
    }

    // Handle any other errors
    res
      .status(500)
      .send({ message: "An error occurred while creating the user.", error });
  }
});

router.post("/login", async (req, res) => {
  try {
    const { email, password } = req.body;
    const user = await User.findOne({ where: { email } });
    console.log(user)
    if (!user) {
      return res.status(400).json({ message: "Invalid email or password!" });
    }

    // If you are using plain text passwords (not recommended), you can directly compare:
    if (user.password !== password) {
      return res.status(400).json({ message: "Invalid password" });
    }

    res.status(200).json({ message: "Login successful", user });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

module.exports = router;
