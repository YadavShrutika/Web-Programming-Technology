const { Sequelize, DataTypes } = require("sequelize");

const sequelize = new Sequelize("webistaan1", "root", "cdac", {
  host: "localhost",
  dialect: "mysql",
});

// Define the EventBooking model
const EventBooking = sequelize.define("EventBooking", {
  eventTitle: {
    type: DataTypes.STRING,
    allowNull: false,
    validate: {
      len: [3, 255], // Event title length validation
    },
  },
  eventDate: {
    type: DataTypes.DATEONLY, 
    allowNull: false,
  },
  eventTime: {
    type: DataTypes.TIME, 
    allowNull: false,
  },
  eventVenue: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  numberOfTickets: {
    type: DataTypes.INTEGER,
    allowNull: false,
    validate: {
      min: 1, // Minimum 1 ticket
      max: 5, // Maximum 5 tickets
    },
  },
  createdAt: {
    type: DataTypes.DATE,
    defaultValue: Sequelize.NOW,
  },
  updatedAt: {
    type: DataTypes.DATE,
    defaultValue: Sequelize.NOW,
  },
});

module.exports = EventBooking;

