const express = require("express");
const path = require("path");
const cors = require("cors");
const app = express();
app.use(express.json());
app.use(cors());
const buildPath = path.join(__dirname, "..", "build");
app.use(express.static(buildPath));
const mysql2 = require("mysql2");

// Create a connection object with the necessary database credentials
const db = mysql2.createConnection({
  host: "localhost", // Database host
  user: "root", // Database username
  password: "cdac", // Database password
  database: "webistaan1", // Database name
});

app.use("/api", require("./routes/RegisterUser"));
app.use("/api", require("./routes/EventData"));

// Connect to the database
db.connect((err) => {
  if (err) {
    console.error("Error connecting to the database:", err);
    return;
  }
  console.log("Connected to the MySQL database");
});

// Start the server and listen on port 5000
app.listen(5000, () => {
  console.log("Server started on port 5000");
});






//start with nodemon index.js    